package com.samsung.android.escrow.threadmodeling;

import android.os.Bundle;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.AdapterView;
import android.widget.ArrayAdapter;
import android.widget.Spinner;
import androidx.fragment.app.Fragment;

// FragmentA.java
public class FragmentA extends Fragment  implements AdapterView.OnItemSelectedListener{

    private Spinner spinner;
    private ArrayAdapter <String> spinnerAdapter;


    // TODO: Rename parameter arguments, choose names that match
    // the fragment initialization parameters, e.g. ARG_ITEM_NUMBER
    private static final String ARG_PARAM1 = "param1";
    private static final String ARG_PARAM2 = "param2";

    // TODO: Rename and change types of parameters
    private String mParam1;
    private String mParam2;

    public FragmentA() {
        // Required empty public constructor
    }

    /**
     * Use this factory method to create a new instance of
     * this fragment using the provided parameters.
     *
     * @param param1 Parameter 1.
     * @param param2 Parameter 2.
     * @return A new instance of fragment SignInFragment.
     */
    // TODO: Rename and change types and number of parameters
    public static FragmentA newInstance(String param1, String param2) {
        FragmentA fragment = new FragmentA();
        Bundle args = new Bundle();
        args.putString(ARG_PARAM1, param1);
        args.putString(ARG_PARAM2, param2);
        fragment.setArguments(args);
        return fragment;
    }

    @Override
    public void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        if (getArguments() != null) {
            mParam1 = getArguments().getString(ARG_PARAM1);
            mParam2 = getArguments().getString(ARG_PARAM2);
        }
    }

    @Override
    public View onCreateView(LayoutInflater inflater, ViewGroup container,
                             Bundle savedInstanceState) {

        String[] users = { "     0", "     1", "     2" };
        View view =inflater.inflate(R.layout.fragment_a,container,false);

        //spinners
        Spinner spin = (Spinner) view.findViewById(R.id.spinner1);
        ArrayAdapter<String> adapter = new ArrayAdapter<>(requireContext(), android.R.layout.simple_spinner_item, users);

        adapter.setDropDownViewResource(android.R.layout.simple_spinner_dropdown_item);
        spin.setAdapter(adapter);
        spin.setOnItemSelectedListener(this);

        Spinner spin2 = (Spinner) view.findViewById(R.id.spinner2);
        spin2.setAdapter(adapter);
        spin2.setOnItemSelectedListener(this);

        Spinner spin3 = (Spinner) view.findViewById(R.id.spinner3);
        spin3.setAdapter(adapter);
        spin3.setOnItemSelectedListener(this);

        Spinner spin4 = (Spinner) view.findViewById(R.id.spinner4);
        spin4.setAdapter(adapter);
        spin4.setOnItemSelectedListener(this);

        Spinner spin5 = (Spinner) view.findViewById(R.id.spinner5);
        spin5.setAdapter(adapter);
        spin5.setOnItemSelectedListener(this);

        Spinner spin6 = (Spinner) view.findViewById(R.id.spinner6);
        spin6.setAdapter(adapter);
        spin6.setOnItemSelectedListener(this);

        Spinner spin7 = (Spinner) view.findViewById(R.id.spinner7);
        spin7.setAdapter(adapter);
        spin7.setOnItemSelectedListener(this);

        // Inflate the layout for this fragment
        return view;
    }

    public void onItemSelected(AdapterView<?> arg0, View arg1, int position, long id) {
        String[] users = { "0", "1", "2" };
//        Toast.makeText(requireContext(), "Selected case: "+users[position] ,Toast.LENGTH_SHORT).show();
    }
    @Override
    public void onNothingSelected(AdapterView<?> arg0) {
        // TODO - Custom Code
    }

}
