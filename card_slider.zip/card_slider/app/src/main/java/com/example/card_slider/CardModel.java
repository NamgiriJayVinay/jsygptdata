package com.example.card_slider;

public class CardModel {
    private String text;

    public CardModel(String text) {
        this.text = text;
    }

    public String getText() {
        return text;
    }
}
