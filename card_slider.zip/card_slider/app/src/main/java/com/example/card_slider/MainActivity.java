package com.example.card_slider;

import android.os.Bundle;
import android.view.View;
import android.widget.LinearLayout;
import android.widget.TextView;

import androidx.appcompat.app.AppCompatActivity;
import androidx.viewpager2.widget.ViewPager2;

import java.util.ArrayList;
import java.util.List;

public class MainActivity extends AppCompatActivity {

    private ViewPager2 viewPager;
    private LinearLayout dotsContainer;
    private List<CardModel> cardModelList;
    private int dotCount = 0;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);

        viewPager = findViewById(R.id.viewPager);
        dotsContainer = findViewById(R.id.dots_container);

        cardModelList = new ArrayList<>();
        cardModelList.add(new CardModel("Card 1"));
        cardModelList.add(new CardModel("Card 2"));
        cardModelList.add(new CardModel("Card 3"));
        cardModelList.add(new CardModel("Card 4"));
        cardModelList.add(new CardModel("Card 5"));

        CardAdapter adapter = new CardAdapter(cardModelList);
        viewPager.setAdapter(adapter);

        dotCount = cardModelList.size();
        addDotIndicators(dotCount);

        viewPager.registerOnPageChangeCallback(new ViewPager2.OnPageChangeCallback() {
            @Override
            public void onPageSelected(int position) {
                super.onPageSelected(position);
                updateDotIndicators(position);
            }
        });
    }

    private void addDotIndicators(int count) {
        for (int i = 0; i < count; i++) {
            View dot = new View(this);
            LinearLayout.LayoutParams params = new LinearLayout.LayoutParams(
                    16, 16); // Width and height for each dot
            params.setMargins(8, 0, 8, 0); // Margins between dots
            dot.setLayoutParams(params);
            dot.setBackgroundResource(R.drawable.dot_selector); // Create a drawable for dot selector
            dotsContainer.addView(dot);
        }
    }

    private void updateDotIndicators(int position) {
        for (int i = 0; i < dotsContainer.getChildCount(); i++) {
            View dot = dotsContainer.getChildAt(i);
            if (i == position) {
                dot.setSelected(true);
            } else {
                dot.setSelected(false);
            }
        }
    }
}
