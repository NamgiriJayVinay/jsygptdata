package com.example.dropdownmaterial;

import android.content.Context;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.ArrayAdapter;
import android.widget.ImageView;
import android.widget.TextView;

import com.example.dropdownmaterial.AppInfo;

import java.util.List;

public class AppAdapter extends ArrayAdapter<AppInfo> {
    private LayoutInflater inflater;

    public AppAdapter(Context context, List<AppInfo> apps) {
        super(context, 0, apps);
        inflater = LayoutInflater.from(context);
    }

    @Override
    public View getView(int position, View convertView, ViewGroup parent) {
        return createItemView(position, convertView, parent);
    }

    @Override
    public View getDropDownView(int position, View convertView, ViewGroup parent) {
        return createItemView(position, convertView, parent);
    }

    private View createItemView(int position, View convertView, ViewGroup parent) {
        if (convertView == null) {
            convertView = inflater.inflate(R.layout.spinner_item, parent, false);
        }

        ImageView iconView = convertView.findViewById(R.id.appIcon);
        TextView nameView = convertView.findViewById(R.id.appName);

        AppInfo app = getItem(position);
        if (app != null) {
            iconView.setImageBitmap(app.getIcon());
            nameView.setText(app.getName());
        }

        return convertView;
    }
}