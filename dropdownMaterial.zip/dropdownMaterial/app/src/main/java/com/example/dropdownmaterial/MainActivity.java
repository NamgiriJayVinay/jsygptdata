package com.example.dropdownmaterial;

import android.content.pm.ApplicationInfo;
import android.content.pm.PackageManager;
import android.graphics.Bitmap;
import android.graphics.Canvas;
import android.graphics.drawable.BitmapDrawable;
import android.graphics.drawable.ColorDrawable;
import android.graphics.drawable.Drawable;
import android.os.Bundle;
import android.view.View;
import android.widget.AdapterView;
import android.widget.Spinner;
import android.widget.Toast;

import androidx.appcompat.app.AppCompatActivity;
import androidx.core.content.ContextCompat;

import java.util.ArrayList;
import java.util.Collections;
import java.util.List;

public class MainActivity extends AppCompatActivity {

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);

        Spinner appSpinner = findViewById(R.id.appSpinner);
        List<AppInfo> appList = getInstalledApps();

        AppAdapter adapter = new AppAdapter(this, appList);
        appSpinner.setAdapter(adapter);

        // Set custom popup background
        appSpinner.setPopupBackgroundDrawable(new ColorDrawable(ContextCompat.getColor(this, R.color.spinner_background)));

        appSpinner.setOnItemSelectedListener(new AdapterView.OnItemSelectedListener() {
            @Override
            public void onItemSelected(AdapterView<?> parent, View view, int position, long id) {
                AppInfo selectedApp = (AppInfo) parent.getItemAtPosition(position);
                String message = selectedApp.getPackageName() + " was selected";
                Toast.makeText(MainActivity.this, message, Toast.LENGTH_SHORT).show();
            }

            @Override
            public void onNothingSelected(AdapterView<?> parent) {
                // Do nothing
            }
        });
    }


    private List<AppInfo> getInstalledApps() {
        List<AppInfo> apps = new ArrayList<>();
        PackageManager pm = getPackageManager();
        List<ApplicationInfo> packages = pm.getInstalledApplications(PackageManager.GET_META_DATA);

        for (ApplicationInfo packageInfo : packages) {
            String packageName = packageInfo.packageName;

            // Filter apps to include only those starting with "com.example"
            if (packageName.startsWith("com.example.")) {
                String appName = pm.getApplicationLabel(packageInfo).toString();
                Bitmap icon = drawableToBitmap(packageInfo.loadIcon(pm));
                apps.add(new AppInfo(appName, packageName, icon));
            }
        }

        Collections.sort(apps, (a1, a2) -> a1.getName().compareToIgnoreCase(a2.getName()));
        return apps;
    }

    private Bitmap drawableToBitmap(Drawable drawable) {
        if (drawable instanceof BitmapDrawable) {
            return ((BitmapDrawable) drawable).getBitmap();
        }

        int width = drawable.getIntrinsicWidth();
        width = width > 0 ? width : 1;
        int height = drawable.getIntrinsicHeight();
        height = height > 0 ? height : 1;

        Bitmap bitmap = Bitmap.createBitmap(width, height, Bitmap.Config.ARGB_8888);
        Canvas canvas = new Canvas(bitmap);
        drawable.setBounds(0, 0, canvas.getWidth(), canvas.getHeight());
        drawable.draw(canvas);

        return bitmap;
    }
}