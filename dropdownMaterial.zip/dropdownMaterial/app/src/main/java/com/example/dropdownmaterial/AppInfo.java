package com.example.dropdownmaterial;

import android.graphics.Bitmap;

public class AppInfo {
    private String name;
    private String packageName;
    private Bitmap icon;

    public AppInfo(String name, String packageName, Bitmap icon) {
        this.name = name;
        this.packageName = packageName;
        this.icon = icon;
    }

    public String getName() {
        return name;
    }

    public String getPackageName() {
        return packageName;
    }

    public Bitmap getIcon() {
        return icon;
    }
}